#include "stack_first.h"
#include <stdio.h>

int main(void)
{
	int *new_stack = NULL;

	push(new_stack, 10);
	push(new_stack, 20);
	push(new_stack, 30);
	print_stack(new_stack);
	pop(new_stack);
	pop(new_stack);
	pop(new_stack);
	pop(new_stack);

	return 0;
}