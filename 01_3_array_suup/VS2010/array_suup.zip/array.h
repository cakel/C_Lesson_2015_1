#define MAX(a, b) (a) > (b) ? a : b
#define MIN(a, b) (a) < (b) ? a : b
#define END_OF_ARRAY (-1)

void initialize_array(int** array);
void finalize_array(int **array);
void print_array(int array[]);
void sort_array(int *array);
void print_array(int array[]);
int find_count(int* array);
